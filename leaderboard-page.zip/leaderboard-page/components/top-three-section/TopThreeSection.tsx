import React from "react";
import { User } from "../../../../types";
import TopThreeCard from "./TopThreeCard";

interface TopThreeProps {
  users: User[],
}

const TopThreeSection: React.FC<TopThreeProps> = ({ users }) => {
  return (
    <>
      
        <div className="flex items-center justify-between w-full h-auto mb-8">
             <TopThreeCard usersInfo={users}  />
         
        </div>
  
    </>
  );
};

export default TopThreeSection;