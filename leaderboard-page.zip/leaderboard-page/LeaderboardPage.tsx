import { useEffect, useState } from "react";
import PageNavigator from "../base.components/PageNavigator";
import LeaderTable from "./components/leader-table/LeaderTable";
import TopThreeSection from "./components/top-three-section/TopThreeSection";
import { User } from "../../types";
import axios from "axios";

const LeaderboardPage = () => {
  // Initialize users as an empty array
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const url = "http://10.4.53.25:9996/users";
    axios.get(url).then(response => {
      const sortedUsers = response.data.sort((a:User, b:User) => b.stats_coins - a.stats_coins);
      setUsers(sortedUsers);
      console.log(sortedUsers);
    });
  }, []);
  
  return (
    
    <>
    <div className='h-screen bg-secondary-800 flex'>
      <div className="w-[10%] flex justify-center items-center">
        <PageNavigator page=''/>
      </div>
      <div className="w-[80%] flex flex-col justify-center items-center">
        {/* Pass users as props */}
        <TopThreeSection users={users.slice(0,3)} />
        <LeaderTable users={users.slice(3,10)} />
      </div>
      <div className="w-[10%] flex justify-center items-center">
      </div>
    </div>
    </>
    
  );
}

export default LeaderboardPage;